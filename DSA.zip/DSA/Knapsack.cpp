#include <iostream.h>
#include <conio.h>
int main() {
    int array[2][100], n, w, i, curw, used[100], maxi = -1;
    float totalprofit = 0;

    cout << "Knapsack using Greedy Method\n";
    cout << "~~~~~~~~~~~~~~~~~~~~~~~~~~~~\n";
    cout << "Enter number of objects: ";
    cin >> n;
    cout << "Enter the weight of the knapsack: ";
    cin >> w;

    cout << "Enter weight and profit of each object:\n";
    for (i = 0; i < n; i++) {
        cout << "Object " << i + 1 << ": ";
        cin >> array[0][i] >> array[1][i];
    }

    for (i = 0; i < n; i++) {
        used[i] = 0;  // Initialize used array to zero
    }

    curw = w;
    while (curw > 0) {
        maxi = -1;
        for (i = 0; i < n; i++) {
            if ((used[i] == 0) && (maxi == -1 || 
                ((float)array[1][i] / (float)array[0][i]) > 
                ((float)array[1][maxi] / (float)array[0][maxi]))) {
                maxi = i;
            }
        }

        if (maxi == -1) {
            break; // No more items to consider
        }

        used[maxi] = 1;
        if (curw >= array[0][maxi]) {
            curw -= array[0][maxi];
            totalprofit += array[1][maxi];
            cout << "\nAdded object " << maxi + 1 
                 << " Weight: " << array[0][maxi] 
                 << " Profit: " << array[1][maxi]
                 << " completely in the bag, Space left: " << curw;
        } else {
            totalprofit += ((float)array[1][maxi] / array[0][maxi]) * curw;
            cout << "\nAdded object " << maxi + 1 
                 << " Weight: " << curw 
                 << " Profit: " 
                 << ((float)array[1][maxi] / array[0][maxi]) * curw
                 << " partially in the bag, Space left: 0";
            curw = 0;
        }
    }

    cout << "\n\nTotal profit in the knapsack: " << totalprofit << endl;
    return 0;
}
