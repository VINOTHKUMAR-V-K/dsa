#include <iostream.h>
#include <stdlib.h> // For malloc and free

#include <conio.h>

struct Node {
    int data;
    struct Node* next;
};

struct Node* top = NULL;

// Function to push an element onto the stack
void push(int val) {
    struct Node* newnode = (struct Node*)malloc(sizeof(struct Node));
    newnode->data = val;
    newnode->next = top;
    top = newnode;
    cout << "Value " << val << " pushed onto the stack." << endl;
}

// Function to pop an element from the stack
void pop() {
    if (top == NULL) {
        cout << "Stack Underflow" << endl;
    } else {
        cout << "The popped element is " << top->data << endl;
        struct Node* temp = top;
        top = top->next;
        free(temp);
    }
}

// Function to display the stack elements
void display() {
    struct Node* ptr;
    if (top == NULL) {
        cout << "Stack is empty" << endl;
    } else {
        ptr = top;
        cout << "Stack elements are: ";
        while (ptr != NULL) {
            cout << ptr->data << " ";
            ptr = ptr->next;
        }
        cout << endl;
    }
}

int main() {
    int ch, val;
    cout << "Stack Using Linked List" << endl;
    cout << "***********************" << endl;
    cout << "1. Push in stack" << endl;
    cout << "2. Pop from stack" << endl;
    cout << "3. Display stack" << endl;
    cout << "4. Exit" << endl;

    do {
        cout << "Enter choice: ";
        cin >> ch;
        switch (ch) {
            case 1: {
                cout << "Enter value to be pushed: ";
                cin >> val;
                push(val);
                break;
            }
            case 2: {
                pop();
                break;
            }
            case 3: {
                display();
                break;
            }
            case 4: {
                cout << "Exit" << endl;
                break;
            }
            default: {
                cout << "Invalid Choice" << endl;
            }
        }
    } while (ch != 4);

    return 0;
}
