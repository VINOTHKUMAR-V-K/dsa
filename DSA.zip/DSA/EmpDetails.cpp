#include <iostream.h>
#include <fstream.h>
#include <string.h>
#include <cstdlib.h> // for exit()
#include <cstring.h> // for strcmp

#include <conio.h>

const char empfile[] = "Employee.txt"; 
const char ITfile[] = "IT.txt"; 
const char Adminfile[] = "Admin.txt"; 
const char Prodfile[] = "Production.txt"; 
const char Salesfile[] = "Sales.txt"; 

class emp {
    int empid; 
    string name; 
    string address; 
    int age; 
public: 
    string dept; 
    void get(); 
    const string& getdept() const { 
        return dept; 
    } 
    void writeToStream(ofstream& fout) const; 
    void readFromStream(ifstream& fin); 
};

void emp::get() { 
    cout << "\nEnter Employee Id: "; 
    cin >> empid; 
    cin.ignore(); // To ignore the newline after entering empid
    cout << "\nEnter Name: "; 
    getline(cin, name); 
    cout << "\nEnter Address: "; 
    getline(cin, address); 
    cout << "\nEnter Department Name (Admin/Sales/IT/Production): "; 
    getline(cin, dept); 
    cout << "\nEnter Age: "; 
    cin >> age; 
}

// Serialize emp object
void emp::writeToStream(ofstream& fout) const {
    fout.write(reinterpret_cast<const char*>(&empid), sizeof(empid));
    size_t nameLength = name.size();
    fout.write(reinterpret_cast<const char*>(&nameLength), sizeof(nameLength));
    fout.write(name.c_str(), nameLength);
    
    size_t addressLength = address.size();
    fout.write(reinterpret_cast<const char*>(&addressLength), sizeof(addressLength));
    fout.write(address.c_str(), addressLength);
    
    fout.write(reinterpret_cast<const char*>(&age), sizeof(age));
    
    size_t deptLength = dept.size();
    fout.write(reinterpret_cast<const char*>(&deptLength), sizeof(deptLength));
    fout.write(dept.c_str(), deptLength);
}

// Deserialize emp object
void emp::readFromStream(ifstream& fin) {
    fin.read(reinterpret_cast<char*>(&empid), sizeof(empid));
    
    size_t nameLength;
    fin.read(reinterpret_cast<char*>(&nameLength), sizeof(nameLength));
    name.resize(nameLength);
    fin.read(&name[0], nameLength);
    
    size_t addressLength;
    fin.read(reinterpret_cast<char*>(&addressLength), sizeof(addressLength));
    address.resize(addressLength);
    fin.read(&address[0], addressLength);
    
    fin.read(reinterpret_cast<char*>(&age), sizeof(age));
    
    size_t deptLength;
    fin.read(reinterpret_cast<char*>(&deptLength), sizeof(deptLength));
    dept.resize(deptLength);
    fin.read(&dept[0], deptLength);
}

void insert() { 
    emp e; 
    ofstream fout; 
    fout.open(empfile, ios::binary | ios::app); 
    if (!fout) { 
        cout << "\nUnable to Open the File!!!"; 
        exit(EXIT_FAILURE); 
    } 
    e.get(); 
    e.writeToStream(fout); 
    cout << "\nRecord Inserted !!!" << endl; 
    fout.close(); 
} 

void sort() { 
    emp e; 
    ofstream adm(Adminfile, ios::binary | ios::app); 
    ofstream sal(Salesfile, ios::binary | ios::app); 
    ofstream pro(Prodfile, ios::binary | ios::app); 
    ofstream it(ITfile, ios::binary | ios::app); 
    ifstream fin(empfile, ios::binary); 
    
    if (!fin) { 
        cout << "Unable to open Employee file." << endl; 
        return; 
    }
    
    while (fin.read(reinterpret_cast<char*>(&e), sizeof(e))) { 
        e.readFromStream(fin);
        
        if (e.getdept() == "Admin") { 
            adm.write(reinterpret_cast<char*>(&e), sizeof(e)); 
            cout << "\nRecord Inserted into ADMIN File!!!"; 
        } else if (e.getdept() == "Sales") { 
            sal.write(reinterpret_cast<char*>(&e), sizeof(e)); 
            cout << "\nRecord Inserted into SALES File!!!"; 
        } else if (e.getdept() == "IT") { 
            it.write(reinterpret_cast<char*>(&e), sizeof(e)); 
            cout << "\nRecord Inserted into IT File!!!"; 
        } else if (e.getdept() == "Production") { 
            pro.write(reinterpret_cast<char*>(&e), sizeof(e)); 
            cout << "\nRecord Inserted into Production File!!!"; 
        } else { 
            cout << "\nInsert Correct Record!!!"; 
        } 
    } 
    fin.close(); 
    adm.close(); 
    sal.close(); 
    it.close(); 
    pro.close(); 
} 

int main() { 
    int n; 
    cout << "\nEnter No. of Records You Want?: "; 
    cin >> n; 
    for (int i = 0; i < n; i++) { 
        insert(); 
    } 
    sort(); 
    return 0; 
}
