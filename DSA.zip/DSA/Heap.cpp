#include <iostream.h>
#include <conio.h>

// Function to heapify the array
void heapify(int heap[], int n) {
    int i, j, c, root, temp;
    for (j = n - 1; j >= 0; j--) {
        temp = heap[0];
        heap[0] = heap[j];
        heap[j] = temp;
        root = 0;
        do {
            c = 2 * root + 1;
            if ((c < j - 1) && (heap[c] < heap[c + 1])) {
                c++;
            }
            if (c < j && heap[root] < heap[c]) {
                temp = heap[root];
                heap[root] = heap[c];
                heap[c] = temp;
            }
            root = c;
        } while (c < j);
    }
}

// Function to build a max heap
void build_maxheap(int heap[], int n) {
    int i, j, c, r, t;
    for (i = 1; i < n; i++) {
        c = i;
        do {
            r = (c - 1) / 2;
            if (heap[r] < heap[c]) {
                t = heap[r];
                heap[r] = heap[c];
                heap[c] = t;
            }
            c = r;
        } while (c != 0);
    }

    cout << "Heap array: ";
    for (i = 0; i < n; i++) {
        cout << heap[i] << " ";
    }
    cout << endl;
}

int main() {
    int n = 5;
    int heap[10] = {2, 5, 7, 1, 3};

    cout << "Program for Heapsort\n";
    cout << "~~~~~~~~~~~~~~~~~~~~\n";

    // Build the max heap
    build_maxheap(heap, n);

    // Perform heap sort
    heapify(heap, n);

    // Print the sorted array
    cout << "The sorted array is: ";
    for (int i = 0; i < n; i++) {
        cout << heap[i] << " ";
    }
    cout << endl;

    return 0;
}
