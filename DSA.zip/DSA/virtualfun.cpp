#include <iostream.h>
#include <conio.h>

class Base {
public:
    virtual void show() {
        cout << "\nBase class show";
    }
    void display() {
        cout << "\nBase class display";
    }
};

class Derived : public Base {
public:
    void display() {
        cout << "\nDerived class display";
    }
    void show() {
        cout << "\nDerived class show";
    }
};

int main() {
    Base obj1;
    Base* p;

    cout << "Program using Virtual Function\n";
    cout << "******************************\n";

    cout << "\n\tP points to Base:\n";
    p = &obj1;
    p->display();
    p->show();

    cout << "\n\n\tP points to Derived:\n";
    Derived obj2;
    p = &obj2;
    p->display();
    p->show();

    return 0;
}
