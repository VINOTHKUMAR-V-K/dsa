#include <iostream.h>
#include <math.h>
#include <conio.h>

int board[20], count = 0;

void print_board(int n) {
    int i, j;
    cout << "\nSolution " << ++count << ":\n";

    for (i = 1; i <= n; i++) {
        cout << "\t" << i;
    }
    cout << endl;

    for (i = 1; i <= n; i++) {
        cout << "\n" << i;
        for (j = 1; j <= n; j++) {
            if (board[i] == j)
                cout << "\tQ"; // Queen at i, j position
            else
                cout << "\t-"; // Empty slot
        }
        cout << endl;
    }
}

int place(int row, int column) {
    for (int i = 1; i <= row - 1; i++) {
        if (board[i] == column || abs(board[i] - column) == abs(i - row)) {
            return 0;
        }
    }
    return 1;
}

void queen(int row, int n) {
    for (int column = 1; column <= n; column++) {
        if (place(row, column)) {
            board[row] = column;
            if (row == n) {
                print_board(n);
            } else {
                queen(row + 1, n);
            }
        }
    }
}

int main() {
    int n;
    cout << "\nN Queen's Problem using Backtracking";
    cout << "\n***********************************";
    cout << "\nEnter number of Queens: ";
    cin >> n;

    queen(1, n); // Start solving the problem from the first row

    if (count == 0) {
        cout << "\nNo solutions exist for " << n << " queens.";
    }

    return 0;
}
