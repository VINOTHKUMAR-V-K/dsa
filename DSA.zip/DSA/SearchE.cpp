#include <iostream.h>
#include <conio.h>

void search(int a[], int beg, int end, int item) {
    if (beg > end) {
        cout << "\nElement is not found." << endl;
        return;
    }

    int mid = (beg + end) / 2;
    if (item == a[mid]) {
        cout << "\nThe element is found at position: " << mid << endl;
        return;
    } else if (item < a[mid]) {
        search(a, beg, mid - 1, item);
    } else {
        search(a, mid + 1, end, item);
    }
}

int main() {
    int a[100], item, n, beg, end;
    cout << "\nSearching an element using Divide and Conquer\n";
    cout << "**********************************************\n";
    cout << "Enter the number of elements: ";
    cin >> n;

    cout << "\nEnter the elements in sorted order:\n";
    for (int i = 0; i < n; i++) {
        cin >> a[i];
    }

    cout << "\nEnter the element to be searched: ";
    cin >> item;
    
    beg = 0;
    end = n - 1;
    
    search(a, beg, end, item);
    
    return 0;
}
