#include <iostream.h>
#include <conio.h>

class base {
public:
    int x;
    void getdata() {
        cout << "Enter the value of x = ";
        cin >> x;
    }
};

class derive : public base {
private:
    int y;

public:
    void readdata() {
        cout << "Enter the value of y = ";
        cin >> y;
    }

    void product() {
        cout << "Product = " << x * y << endl;
    }
};

int main() {
    derive a;
    cout << "Program for Single Inheritance\n";
    cout << "~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~\n";
    a.getdata();
    a.readdata();
    a.product();

    cin.get(); // Wait for user input before exiting
    return 0; // Return success
}
