#include <iostream.h>
#include <conio.h>

class base {
    int val1, val2;

public:
    void get() {
        cout << "Enter two values: ";
        cin >> val1 >> val2;
    }

    friend float mean(base ob); // Friend function declaration
};

float mean(base ob) {
    return float(ob.val1 + ob.val2) / 2; // Calculate mean
}

int main() { // Change void main() to int main()
    base obj;
    cout << "\nProgram Using Friend Function";
    cout << "\n~~~~~~~~~~~~~~~~~~~~~~~~~~~~~\n";
    obj.get(); // Get values from user
    cout << "\nMean value is: " << mean(obj); // Display mean value
    cin.get(); // Wait for user input before exiting
    return 0; // Return success
}
