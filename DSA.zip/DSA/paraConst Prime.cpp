#include <iostream.h>
#include <conio.h>

class Prime {
    int a, k;

public:
    Prime(int x) {
        a = x;
        k = 1; // Assume it's prime by default
        if (a <= 1) { // 0 and 1 are not prime numbers
            k = 0;
        } else {
            for (int i = 2; i <= a / 2; i++) {
                if (a % i == 0) {
                    k = 0; // Not prime
                    break;
                }
            }
        }
    }

    void show() {
        if (k == 1)
            cout << a << " is a Prime Number." << endl;
        else
            cout << a << " is Not a Prime Number." << endl;
    }
};

int main() {
    int a;
    cout << "Program for Parameterized Constructor \n";
    cout << "\nEnter the Number: ";
    cin >> a;
    Prime obj(a);
    obj.show();
    return 0;
}
