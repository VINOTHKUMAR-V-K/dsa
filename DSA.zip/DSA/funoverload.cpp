#include <iostream.h>
#include <cstdlib.h> // for exit()
#define pi 3.14

#include <conio.h>

class fn {
public:
    void area(int);           // Circle
    void area(int, int);      // Rectangle
    void area(float, int, int); // Triangle
};

void fn::area(int a) {
    cout << "Area of Circle: " << pi * a * a << endl;
}

void fn::area(int a, int b) {
    cout << "Area of Rectangle: " << a * b << endl;
}

void fn::area(float t, int a, int b) {
    cout << "Area of Triangle: " << t * a * b << endl;
}

int main() { // Changed from void main() to int main()
    int ch;
    int a, b, r;
    fn obj;

    cout << "\n\t\tFunction Overloading";
    
    do {
        cout << "\n1. Area of Circle\n2. Area of Rectangle\n3. Area of Triangle\n4. Exit\n";
        cout << "Enter your Choice: ";
        cin >> ch;

        switch (ch) {
            case 1:
                cout << "Enter Radius of the Circle: ";
                cin >> r;
                obj.area(r);
                break;
            case 2:
                cout << "Enter Sides of the Rectangle: ";
                cin >> a >> b;
                obj.area(a, b);
                break;
            case 3:
                cout << "Enter Base and Height of the Triangle: ";
                cin >> a >> b;
                obj.area(0.5, a, b);
                break;
            case 4:
                cout << "Exiting program..." << endl;
                exit(0);
            default:
                cout << "Invalid choice. Please try again." << endl;
        }
    } while (ch != 4);

    cin.get(); // Wait for user input before exiting
    return 0; // Return success
}
